```python
import importlib
import FantasyStats
importlib.reload(FantasyStats)
from FantasyStats import FantasyStats
import matplotlib.pyplot as plt
import numpy as np
from tabulate import tabulate
```


```python
espn_s2 = """AEAYIfzaE2GVGEYIl%2BmjnJirAG6yVsXKWx3%2B2vOP%2BwKYvumjLA0J02VsEIS0Gl1%2BYu3kGSEWnUrY2F1j8Q8fdJD6dU9%2FxwcTGYy2DNjVoBr50KnYS9R3xswdDQTbW6TnXYj3K71cNRStlArXOa32DSyIti5o6xr%2BgUSF3rzUdZS3wYm%2Bcl4vGWaiJhxb0AqWht%2Fua11frWx7kLq7HMu9oZMRu%2B%2Fqr35sQVV1ZireRUtN9gkkKd4BDDXVQyBQmE04UUC6ziQhadLkY6NqT8Dnqnsx"""
swid = "{4AE284FB-293E-4D3D-8683-643DCEC14E29}"
goat = FantasyStats(847378845, 2021,swid=swid, espn_s2=espn_s2)
reg_season = [0,12]
```


```python
scores,ranks = goat.get_weeks_scores(reg_season)
```

## Mean Score and standard deviation


```python
txt = goat.print_mean_points(scores,sort=0)
```

        team                                   mean score      std
    --  -----------------------------------  ------------  -------
     1  Team(Team SLOWen szabo)                  115.757   20.1618
     2  Team(corn man)                           109.523   16.0869
     3  Team(De'Coldest ToEvaDoIt)               104.565   20.3907
     4  Team(Oliver Clozoff)                     103.568   18.9269
     5  Team(Dunham King Chesney's)              101.585   28.641
     6  Team(Kentucky Fried Rice)                 98.945   32.5729
     7  Team(Team Favata)                         97.5133  16.277
     8  Team(Jackson's Hole Fitness Lovers)       97.425   19.1539
     9  Team(Team Reed)                           93.5933  31.5941
    10  Team(Team Lecky)                          93.16    24.283
    11  Team(Philly Dilly)                        92.0883  24.6489
    12  Team(Team Lloyd)                          92.02    13.161
    13  Team(Washed up  Dan Stevens)              91.4983  24.8956
    14  Team(Team Crist)                          89.4067  26.4874
    15  Team(Troy Pegasi)                         86.795   24.7217
    16  Team(Team Wyan)                           85.54    24.349
    17  Team(team gibbman)                        84.3483  24.7377
    18  Team(Cooper Troopers)                     81.85    18.1543
    19  Team(Team Troidle)                        81.1983  25.2097
    20  Team(Philadelphia King Yoshi)             70.675   19.77
    

## Weekly Round Robin
Every team plays every other team each week


```python
win_dist = goat.get_batch_dist(reg_season)
win_probs = goat.get_win_probs(reg_season)

wins,losses = goat.get_batch_record(reg_season)
goat.print_wins_losses(wins, losses)
```

        team                             wins    losses
    --  -----------------------------  ------  --------
     1  Team SLOWen szabo                 169        59
     2  corn man                          162        66
     3  De'Coldest ToEvaDoIt              150        78
     4  Oliver Clozoff                    146        82
     5  Dunham King Chesney's             129        99
     6  Jackson's Hole Fitness Lovers     128       100
     7  Team Favata                       120       108
     8  Team Lecky                        119       109
     9  Team Reed                         117       111
    10  Kentucky Fried Rice               116       112
    11  Washed up  Dan Stevens            114       114
    12  Team Lloyd                        110       118
    13  Philly Dilly                      109       119
    14  Team Crist                        105       123
    15  Troy Pegasi                        95       133
    16  Team Wyan                          90       138
    17  team gibbman                       89       139
    18  Team Troidle                       85       143
    19  Cooper Troopers                    76       152
    20  Philadelphia King Yoshi            51       177
    

## Top Half Record
A win is recorded if a team was in the top half of scorers for the week.


```python
should_win, should_lose = goat.get_tophalf_record(reg_season)
goat.print_wins_losses(should_win, should_lose)
```

        team                             wins    losses
    --  -----------------------------  ------  --------
     1  Team SLOWen szabo                  10         2
     2  Oliver Clozoff                      9         3
     3  De'Coldest ToEvaDoIt                9         3
     4  corn man                            9         3
     5  Team Lecky                          7         5
     6  Philly Dilly                        7         5
     7  Jackson's Hole Fitness Lovers       7         5
     8  Dunham King Chesney's               6         6
     9  Kentucky Fried Rice                 6         6
    10  Team Reed                           6         6
    11  Washed up  Dan Stevens              6         6
    12  team gibbman                        5         7
    13  Team Lloyd                          5         7
    14  Team Troidle                        5         7
    15  Team Crist                          5         7
    16  Team Favata                         5         7
    17  Team Wyan                           4         8
    18  Cooper Troopers                     4         8
    19  Troy Pegasi                         4         8
    20  Philadelphia King Yoshi             1        11
    

## Luck Factor
This is an estimate of the probability that a team would finish with a record worse than or equal to their true record. Since weekly matchups are arbitrary and random some teams record wins despite having lower scores. Higher Luck factor means a team finished with a better record than expected based on their weekly scoring. .5 = finished as expected.

Calculations come from binomial distribution using mean win probability. small approximation error comes from the true probabilities being non-uniform discrete values.


```python
goat.print_win_cdf(win_probs)
```

    team                                   prob of <= true wins
    -----------------------------------  ----------------------
    Team(Oliver Clozoff)                              0.0540673
    Team(Dunham King Chesney's)                       0.0554736
    Team(team gibbman)                                0.187026
    Team(Team Troidle)                                0.223907
    Team(Troy Pegasi)                                 0.30828
    Team(corn man)                                    0.314407
    Team(Cooper Troopers)                             0.322424
    Team(Team Wyan)                                   0.36773
    Team(Team SLOWen szabo)                           0.445156
    Team(Washed up  Dan Stevens)                      0.5
    Team(Team Favata)                                 0.64011
    Team(Team Lecky)                                  0.652083
    Team(Team Reed)                                   0.67556
    Team(Kentucky Fried Rice)                         0.687045
    Team(De'Coldest ToEvaDoIt)                        0.701261
    Team(Jackson's Hole Fitness Lovers)               0.746051
    Team(Team Lloyd)                                  0.751957
    Team(Team Crist)                                  0.800163
    Team(Philadelphia King Yoshi)                     0.855192
    Team(Philly Dilly)                                0.89806
    

## Win Probability by week
 = number of teams beat /(number of teams - 1)

Green - weeks team won

red   - weeks team lost


```python
figure1 = plt.figure(figsize=(15, 15))
cols, rows = 4, 5
for team_id in range(1, goat.n_teams+1):
    figure1.add_subplot(rows, cols, team_id)
    goat.plot_win_probs(win_probs, team_id,show=False)
plt.tight_layout()
plt.show()
```


    
![png](output_12_0.png)
    


## Probability distribution of wins given weekly placings
green indicates true number of wins.

Estimated from simple binomial distribution.


```python
figure1 = plt.figure(figsize=(15, 15))
cols, rows = 4, 5
for team_id in range(1, goat.n_teams+1):
    figure1.add_subplot(rows, cols, team_id)
    goat.plot_win_prob_dist(win_probs, team_id,show=False)
plt.tight_layout()
plt.show()
```


    
![png](output_14_0.png)
    


## Histogram of Matchups won in a week.  
19 indicates team was top scorer in a given week.


```python
figure1 = plt.figure(figsize=(20, 15))
cols, rows = 4, 5
for team_id in range(1, goat.n_teams+1):
    figure1.add_subplot(rows, cols, team_id)
    goat.plot_win_dist(win_dist, team_id,show=False)
plt.tight_layout()
plt.show()
```


    
![png](output_16_0.png)
    


## Charts compiled by team


```python
size = (25,5)
for i in range(1,21):
    goat.all_team_plots(win_dist, win_probs, i, size)
```


    
![png](output_18_0.png)
    



    
![png](output_18_1.png)
    



    
![png](output_18_2.png)
    



    
![png](output_18_3.png)
    



    
![png](output_18_4.png)
    



    
![png](output_18_5.png)
    



    
![png](output_18_6.png)
    



    
![png](output_18_7.png)
    



    
![png](output_18_8.png)
    



    
![png](output_18_9.png)
    



    
![png](output_18_10.png)
    



    
![png](output_18_11.png)
    



    
![png](output_18_12.png)
    



    
![png](output_18_13.png)
    



    
![png](output_18_14.png)
    



    
![png](output_18_15.png)
    



    
![png](output_18_16.png)
    



    
![png](output_18_17.png)
    



    
![png](output_18_18.png)
    



    
![png](output_18_19.png)
    

